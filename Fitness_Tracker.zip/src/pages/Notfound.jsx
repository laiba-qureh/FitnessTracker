import React from 'react'

const Notfound = () => {
  return (
    <div>
      Notfound 404
    </div>
  )
}

export default Notfound
