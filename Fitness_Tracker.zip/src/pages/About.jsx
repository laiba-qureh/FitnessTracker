import React from 'react'

const About = () => {
  return (
    <>
      <section className='px-10 py-10 h-screen bg-zinc-900 text-white' id='about'>
        <h3>About</h3>
      </section>
    </>
  )
}

export default About