import React from "react";
import ICONS from "../assets/constants/icons";
import login from '../assets/images/login.png'

const Home = () => {
  return (
    <>
      <section className="px-10 py-10 h-auto bg-white text-black" id="home">
          <div className="grid grid-cols-1 md:grid-cols-2 text-white">
            {/* Left Column */}
            <div className="m-20">
              <h1 className="text-black font-serif font-bold text-3xl sm:text-4xl md:text-6xl">
                Your Health
              </h1>
              <h1 className="text-black font-serif font-bold text-3xl sm:text-4xl md:text-6xl">
                Our Plan
              </h1>
              <p className="mt-3 text-black sm:text-[8px] md:text-[12px] w-80">
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Unde ullam eum alias! Modi, possimus distinctio accusantium et eius quos esse.
              </p>
              <div className="relative inline-block">
                <button className="mt-5 bg-[#262135] text-white py-2 text-sm w-[120px] rounded-2xl relative">
                  Join
                  <div className="absolute top-0 left-[110px]">
                    <button className="bg-red-500 text-white p-2 mt-1 rounded-full text-xs">
                      <i>
                        <ICONS.RIGHTARROW fontSize={13} />
                      </i>
                    </button>
                  </div>
                </button>
              </div>
              <div className='bg-black w-82 h-[180px] mt-10 rounded-lg p-5'>
                <div className='flex'>
                  <i>
                    <ICONS.HAMBURGER fontSize={80} />
                  </i>
                  <div className="ml-7">
                    <h2 className="text-[18px]">Download Our App</h2>
                    <p className="text-[12px] mt-2">
                      Lorem ipsum dolor sit amet consectetur.
                    </p>
                  </div>

                  <button className="bg-red-500 h-8 w-8 ml-10 text-white p-2 mt-1 rounded-full text-xs">
                    <i>
                      <ICONS.RIGHTARROW fontSize={15} />
                    </i>
                  </button>
                </div>
                <div className="flex items-center  gap-20 mt-3">
                  <h1 className="font-bold text-[18px] ">200K</h1>
                  <h1 className="font-bold text-[18px]">132</h1>
                  <div className='flex  '>
                    <div className="bg-white w-8 h-8 rounded-full overflow-hidden "><img src={login} alt="" /></div>
                    <div className="bg-white w-8 h-8 rounded-full overflow-hidden"><img src={login} alt="" /></div>
                    <div className="bg-white w-8 h-8 rounded-full overflow-hidden"><img src={login} alt="" /></div>
                  </div>
                </div>


                <div className='flex gap-10'>
                  <p className='text-[10px]  '>Lorem ipsum dolor  </p>
                  <p className='text-[10px] '>Lorem ipsum dolor </p>

                </div>


              </div>

            </div>

            <div className=" my-20 mx-[250px] ">
              <div className='bg-yellow-400 w-60 h-32  rounded-2xl text-[15px]'> <img src="" alt="" />Our App is available is on iOS and Android</div>
            </div>

            <div><img src="{pic11}" alt="" /></div>
          </div>


          <div className='bg-black w-full sm:w-[80%] md:w-[1000px] h-[160px] rounded-full mx-auto'>
  
  <div className='flex space-x-8 justify-evenly pt-7'>
    <p className='text-white text-lg md:text-2xl font-bold'>27</p>
    <p className='text-white text-lg md:text-2xl font-bold'>148</p>
    <p className='text-white text-lg md:text-2xl font-bold'>1000</p>
    <p className='text-white text-lg md:text-2xl font-bold'>120k+</p>
  </div>


  <div className='flex space-x-8 justify-evenly py-7 px-10'>
    <p className='text-white text-[8px] md:text-[12px] leading-tight'>Lorem ipsum, dolor sit amet consectetur adipisicin</p>
    <p className='text-white text-[8px] md:text-[12px] leading-tight'>Lorem ipsum dolor sit amet consectetur adipisicing</p>
    <p className='text-white text-[8px] md:text-[12px] leading-tight'>Lorem, ipsum dolor sit amet consectetur adipisicing</p>
    <p className='text-white text-[8px] md:text-[12px] leading-tight'>Lorem ipsum, dolor sit amet consectetur adipisicing</p>
  </div>
</div>


{/* feactures */}
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 mt-24">
  <div className="flex flex-col justify-evenly">
    <h1 className="text-2xl md:text-[40px] font-bold mt-4 font-serif">BEST FEATURES </h1>
    <h1 className="text-2xl md:text-[40px] font-bold mt-2 whitespace-nowrap font-serif">WE OFFER FOR YOU</h1>
  </div>

  <p className="text-sm md:text-sm col-span-1 md:col-span-2 ml-40">
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores autem corporis quis iure illum dolore tenetur.
  </p>



  <div className="bg-black p-4 rounded-lg  h-60 w-80 flex justify-evenly mt-14">
    <h2 className="font-semibold text-lg">Feature 1</h2>
    <p className="text-sm">Description of feature 1.</p>
  </div>
  
  <div className="bg-black p-4 rounded-lg  h-60 w-80 mt-14">
    <h2 className="font-semibold text-lg">Feature 2</h2>
    <p className="text-sm">Description of feature 2.</p>
  </div>

  <div className="bg-black p-4 rounded-lg  h-60 w-80 mt-14">
    <h2 className="font-semibold text-lg">Feature 3</h2>
    <p className="text-sm">Description of feature 3.</p>
  </div>
</div>


      </section>
    </>
  );
};

export default Home;