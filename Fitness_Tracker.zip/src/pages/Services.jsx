import React from 'react'

const Services = () => {
  return (
    <>
      <section className='px-10 py-10 h-screen bg-zinc-900 text-white' id='services'>
        <h3>Services</h3>
      </section>
    </>
  )
}

export default Services