import React from 'react'

const Contact = () => {
  return (
    <>
      <section className='px-10 py-10 h-screen bg-zinc-900 text-white' id='contact'>
        <h3>Contact</h3>
      </section>
    </>
  )
}

export default Contact