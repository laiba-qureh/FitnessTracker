const COLORS={
    theme_yellow:'#efeeb6',
    theme_purple:'#cdbfe7',
    theme_pink:'#fcc6e6',
    theme_blue:'#d6ebeb',
    theme_green_2:'#094847',
    maroon:'#6a4b5d',
    darkblue:'#262135',
    lightgrey:'#e5e6e1',
}
export default COLORS;